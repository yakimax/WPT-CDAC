function addintoTable () {
    let obj = [ ] ;
    let name = document.getElementById('exampleInputEmail1') ;
    let number = document.getElementById('exampleInputPassword1');
    let dest = document.getElementById('Dest');
    let origin = document.getElementById('Origin');
    let clas = document.getElementById('class');
    
 }